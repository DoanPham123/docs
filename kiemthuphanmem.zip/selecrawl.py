# -*- coding: utf-8 -*-

from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import NoSuchElementException        
import mysql.connector
from mysql.connector import Error
from mysql.connector import errorcode




### DEFINE CONSTATN
URL_CRAWL = "https://batdongsan.com.vn/nha-dat-ban-da-nang"
CSS_SELECT_NAVIGATE_ITEM = ".background-pager-right-controls a:nth-last-child(3) div"

## INIT WEB DRIVER : CHROME
driver = webdriver.Chrome()
driver.implicitly_wait(60) 
driver.get(URL_CRAWL)

COUNT = 1

## COMMON FUNCTIONS
def check_exists_by_xpath(cssSelector):
    try:
        driver.find_element_by_css_selector(cssSelector)
    except NoSuchElementException:
        return False
    return True

#### MAIN FUNCTION

try:
    print('Connect DB')
    connection = mysql.connector.connect(host='localhost',
                                         database='bds_crawl',
                                         user='root',
                                         password='Y649394$')

    while True :
        COUNT = COUNT + 1
        if COUNT == 81 :
            break
        
        listItem = driver.find_elements_by_css_selector('.search-productItem')
        
        for item in listItem:
            title = item.find_element_by_css_selector('.p-title a').text    
            print(title)

            price = item.find_element_by_css_selector('.product-price').text
            print(price)

            description = item.find_element_by_css_selector('.p-main-text').text
            print(description)

            distCity = item.find_element_by_css_selector('.product-city-dist').text
            print(distCity)

            uptime = item.find_element_by_css_selector('.uptime').text
            print(uptime)

            productArea = item.find_element_by_css_selector('.product-area').text
            print(productArea)
            
            photoSample = item.find_element_by_css_selector('.product-avatar-img').get_attribute('src')
            print(photoSample)


            # FILTER - INVALID DATA
            # -*- coding: utf-8 -*-
            if price.lower() == u"thỏa thuận" : 
                continue

            if productArea.lower() == u"không xác định" :
                continue

            if u"chung cư" in title.lower():
                continue

            if u"khách sạn" in title.lower():
                continue

            if u"kiệt" in title.lower():
                continue

            if u"căn hộ" in title.lower():
                continue

            if u"villa" in title.lower():
                continue

            if "resort" in title.lower():
                continue

            if "condotel" in title.lower():
                continue

            # INSERT INTO DB
            mySql_insert_query = """INSERT INTO BATDONGSAN ( title, description, image, uptime, price, distcity, space) 
                           VALUES 
                           (%s, %s, %s, %s, %s, %s, %s) """

            insert_tuple_ = (title, description, photoSample, uptime, price, distCity, productArea)

            cursor = connection.cursor()
            cursor.execute(mySql_insert_query, insert_tuple_)
 
            connection.commit()
            print(cursor.rowcount, "Record inserted successfully into Laptop table")
            #cursor.close()
 

        
        navigateItem = driver.find_element_by_css_selector(CSS_SELECT_NAVIGATE_ITEM)        
        navigateItem.click()


    # CLOSE DRIVER
    #driver.close()    


except mysql.connector.Error as error:
    print("Failed to insert record into BDS table {}".format(error))

finally:    
    if (connection.is_connected()):
        connection.close()
        print("MySQL connection is closed")

# # CLOSE DRIVER
# driver.close()

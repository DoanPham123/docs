from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from webdriver_manager.chrome import ChromeDriverManager

# Cấu hình trình duyệt Chrome (chạy ẩn)
options = webdriver.ChromeOptions()
# options.add_argument('--headless')  # Không hiển thị trình duyệt
# options.add_argument('--disable-gpu')
# options.add_argument('--no-sandbox')  # Hỗ trợ chạy trên VPS
# options.add_argument('--disable-dev-shm-usage')

# Khởi tạo WebDriver
driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=options)

# Mở trang web giá vàng
url = 'https://www.24h.com.vn/gia-vang-hom-nay-c425.html'
driver.get(url)

try:
    # Đợi phần tử chứa bảng giá vàng xuất hiện
    table = WebDriverWait(driver, 10).until(
        EC.presence_of_element_located((By.CLASS_NAME, "gia-vang-search-data-table"))
    )

    # Lấy tất cả các hàng trong bảng
    rows = table.find_elements(By.TAG_NAME, "tr")

    print("🔥 Giá vàng hôm nay:")
    for row in rows:
        columns = row.find_elements(By.TAG_NAME, "td")
        if len(columns) >= 3:  # Đảm bảo có đủ cột dữ liệu
            ten_vang = columns[0].text.strip()
            gia_mua = columns[1].text.strip()
            gia_ban = columns[2].text.strip()
            print(f"💰 {ten_vang}: Mua vào {gia_mua} | 💵 Bán ra {gia_ban}")


except Exception as e:
    print("❌ Không tìm thấy dữ liệu giá vàng!", str(e))

# Đóng trình duyệt
driver.quit()

from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import NoSuchElementException        
import mysql.connector
from mysql.connector import Error
from mysql.connector import errorcode


### DEFINE CONSTATN
URL_CRAWL = "https://nha.chotot.com/da-nang/mua-ban-bat-dong-san?page=1"
XPATH_LIST_ITEM = "//*[@id=\"app\"]/div[2]/main/div/div[1]/div[1]/main/div/div[1]/div[7]/div //li/a"

#XPATH_LIST_ITEM = "//*[@id=\"app\"]/div[2]/main/div/div[1]/div[1]/main/div/div[1]/div[7]/div //li/a/div[2]"

XPATH_PRICE = "//span[@class='adPriceNormal']"
XPATH_AREA = " //div[@class='areaName']"
AUTHOR = "//Span[@class='text link']"


## INIT WEB DRIVER : CHROME
driver = webdriver.Chrome()
driver.implicitly_wait(6) 
driver.get(URL_CRAWL)

page = 2

try:
    print('Connect DB')
    connection = mysql.connector.connect(host='localhost',
                                         database='bds_crawl',
                                         user='root',
                                         password='Y649394$')

    while True : 

        listFirsItem = driver.find_elements_by_css_selector('._3qr34_XMQROJG0YnuXtt9c')
        for item in listFirsItem:
            try :

                item.find_element_by_css_selector('h3')
                title = item.find_element_by_css_selector('h3').text  
                print(title)

                price = item.find_element_by_css_selector('._3cghIc99knkUDCu8tAZi-a').text  
                print(price)

                area = item.find_element_by_css_selector('.sc-esjQYD.LiTa:last-child').text  
                print(area)

                mySql_insert_query = """INSERT INTO CHOTOT_BDS_DN ( title, price, area ) 
                           VALUES 
                           (%s, %s, %s) """

                insert_tuple_ = (title, price, area )

                cursor = connection.cursor()
                cursor.execute(mySql_insert_query, insert_tuple_)

                connection.commit()
                print(cursor.rowcount, "Record inserted successfully into Laptop table")
                
                #author = item.find_element_by_css_selector('.sc-kIPQKe.jhePim').text  
                #print(author)

            except NoSuchElementException:
                print('NoSuchElementException')
                continue
            
        driver.get("https://nha.chotot.com/da-nang/mua-ban-bat-dong-san?page=" + str(page))
        page = page + 1
        
except mysql.connector.Error as error:
    print("Failed to insert record into BDS table {}".format(error))

finally:    
    if (connection.is_connected()):
        connection.close()
        print("MySQL connection is closed")
    


#driver.close()

